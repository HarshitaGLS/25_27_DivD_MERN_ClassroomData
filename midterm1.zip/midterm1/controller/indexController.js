const dummy = (req,res)=>{
    res.send("dummy api")
}

export {dummy}